import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../app/script.js';
import '../public/data/DATA.json';

console.log('Hello Coders! :)');